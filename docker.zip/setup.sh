#!/bin/bash

HTTP_BACK="https://gitlab.istic.univ-rennes1.fr/Majistic_2019/uctl_2019.git"
SSH_BACK="git@gitlab.istic.univ-rennes1.fr:Majistic_2019/uctl_2019.git"

HTTP_FRONT="https://gitlab.istic.univ-rennes1.fr/Majistic_2019/uctl2_frontmodel.git"
SSH_FRONT="git@gitlab.istic.univ-rennes1.fr:Majistic_2019/uctl2_frontmodel.git"

HTTP_MANAGER="https://gitlab.istic.univ-rennes1.fr/Majistic_2019/uctl2020_manager.git"
SSH_MANAGER="git@gitlab.istic.univ-rennes1.fr:Majistic_2019/uctl2020_manager.git"

url_back=""
url_front=""
url_manager=""

if [ "$1" = "http" ]; then
    url_back=$HTTP_BACK
    url_front=$HTTP_FRONT
    url_manager=$HTTP_MANAGER
else
    url_back=$SSH_BACK
    url_front=$SSH_FRONT
    url_manager=$SSH_MANAGER
fi

git clone $url_back UCTL2_Back
git clone $url_front UCTL2_Front
git clone $url_manager UCTL2_Manager

docker build -t uctl2_app .