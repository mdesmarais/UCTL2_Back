#!/bin/bash

echo "Updating UCTL2_Back"
cd UCTL2_Back && git pull && cd ..

echo "Update UCTL2_Front"
cd UCTL2_Front && git pull && cd ..

echo "Updating UCTL2_Manager"
cd UCTL2_Manager && git pull && cd ..

echo "Building docker image"
docker build -t uctl2_app .