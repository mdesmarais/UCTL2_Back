#!/bin/sh

. /opt/venv/bin/activate && cd /usr/local/UCTL2_Back && pip install -e . && python uctl2_back/manager.py samples/config.json &
http-server /usr/local/webserver/

exec "$@"