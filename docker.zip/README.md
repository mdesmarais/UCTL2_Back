# Création de l'image

Utilisez l'une des deux commandes pour lancer la création de l'image docker selon votre préférence du mode d'authentification gitlab :

* `./setup.sh` : utilise le mode ssh pour cloner les projets git
* `./setup.sh http` : utilise le mode http pour cloner les projets git

# Lancement de l'application

Python 3 est requis pour utiliser le script de lancement du container.

Executez le script `start.py` avec un interpréteur python 3 pour lancer l'application.

Un serveur web sera lancé, voici les deux adresses disponibles :

* Panneau de contrôle du simulateur : [http://localhost:8080/manager](http://localhost:8080/manager)
* Interface web de la course : [http://localhost:8080/live](http://localhost:8080/live)

Avec la configuration par défaut, le fichier de course modifié sera disponible dans le dossier UCTL2_Back : [UCTL2_Back/race.csv](UCTL2_Back/race.csv).

# Mise à jour de l'application

Pour mettre à jour l'application, il faut exécuter le script update.sh :

`./update.sh`

Les projets git seront mis à jour et l'image docker sera à nouveau construite.