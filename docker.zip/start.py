import json
import os.path
import subprocess
import sys

def docker_bind(src, dest):
    return 'type=bind,src=%s,dst=%s' % (src, dest)

if __name__ == '__main__':
    with open('UCTL2_Back/samples/config.json', 'r') as f:
        json_config = json.load(f)
    
    try:
        race_file = json_config['raceFile']
    except KeyError:
        print('Missing raceFile key in the config file')
        sys.exit(-1)

    race_file_path = os.path.join('UCTL2_Back', race_file)

    if not os.path.isfile(race_file_path):
        try:
            with open(race_file_path, 'w'):
                pass
        except OSError:
            print('Unable to create an empty race file', race_file_path)
            sys.exit(-1)

    running_directory = os.path.dirname(os.path.abspath(__file__))
    
    samples_folder_mount = [
        '--mount',
        docker_bind(os.path.join(running_directory, 'UCTL2_Back/samples/'), '/usr/local/UCTL2_Back/samples')
    ]

    race_file_mount = [
        '--mount',
        docker_bind(os.path.join(running_directory, 'UCTL2_Back', race_file), os.path.join('/usr/local/UCTL2_Back/', race_file))
    ]

    args = ['docker', 'run', '--net', 'host', '-it', '--rm', *samples_folder_mount, *race_file_mount, 'uctl2_app']

    subprocess.run(args)